// var io = require('socket.io').listen(8000);
var key = require('./express-server').apikey;
console.log(key);