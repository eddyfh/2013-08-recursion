'use strict';

angular.module('angyeoApp')
  .controller('FbCtrl', ['$scope', '$http', function ($scope, $http) {
    

  }]);
